import json
from flask import Flask, request
from flask_cors import CORS
from nltk import word_tokenize
from nltk.corpus import stopwords

from sentence_transformers import SentenceTransformer
from waitress import serve
from semantic_text_splitter import TiktokenTextSplitter
from MilvusConfig import MilvusConfig
from DocumentData import DocumentData

from pymilvus import (AnnSearchRequest, RRFRanker)

from pymilvus.model.sparse import SpladeEmbeddingFunction

COLLECTION_NAME = "DEMO_FILTERED_SEARCH"  # Set your collection name
words_to_remove = ["is", "a", ".", ",", "\n", "\\n", "*", "&", ":", "``", "(", ")"]
words_to_remove_chunks = ["\n", "\\n", "*"]

app = Flask(__name__)
CORS(app)

ef_md = SpladeEmbeddingFunction(model_name="naver/splade-cocondenser-selfdistil", device="cpu")
embed_model = SentenceTransformer(model_name_or_path="BAAI/bge-large-en-v1.5")


def sparse_encode_docs(docs):
    docs_embeddings = ef_md.encode_documents(docs)
    return docs_embeddings


def sparse_encode_queries(keywords):
    query_embeddings = ef_md.encode_queries(keywords)
    return query_embeddings


def vec_embeddings(text):
    dense_embeddings = list(embed_model.encode(text, normalize_embeddings=True))
    return dense_embeddings


def parse_content(json_filepath):
    with open(json_filepath) as json_file:
        data = json.load(json_file)
        paragraph_contents = data["documentText"]["content"]
        return paragraph_contents


def parse_doc_details(json_filepath):
    with open(json_filepath) as json_file:
        data = json.load(json_file)
        doc_details = {"doc_id": data["doc_id"], "doc_download_link": data["doc_download_link"]}
        return doc_details


def parse_doc_entities(json_filepath):
    with open(json_filepath) as json_file:
        data = json.load(json_file)
        return data['entities']


def semantic_textsplitter_list(para, max_tokens):
    splitter = TiktokenTextSplitter("gpt-4", trim_chunks=True)
    chunks = splitter.chunks(para, max_tokens)
    return chunks


def dk8668_algo_textsplitter_list(para):
    chunks = str(para).split("\n")

    filtered_chunks_less = [word for word in chunks if len(word) <= 50]  # merger  needed

    filtered_chunks_200 = semantic_textsplitter_list(
        ' '.join([word for word in chunks if 50 < len(word) <= 200]), 400)  # merger  needed

    filtered_chunks_500 = [word for word in chunks if 200 < len(word) <= 500]  # no split needed
    filtered_chunks_1999 = [word for word in chunks if 1000 < len(word) <= 2000]  # no split needed
    filtered_chunks_2000 = [word for word in chunks if len(word) > 2000]  # split needed
    filtered_chunks_2000.insert(len(filtered_chunks_2000), ' '.join(filtered_chunks_less))
    filtered_chunks_2000_splits = semantic_textsplitter_list(' '.join(filtered_chunks_2000), 400)
    filtered_chunk = filtered_chunks_200 + filtered_chunks_500 + filtered_chunks_1999 + filtered_chunks_2000_splits
    return filtered_chunk


@app.route('/drop_collection', methods=['POST'])
def drop_collection():
    MilvusConfig.establish_connection()
    MilvusConfig.drop_collection(COLLECTION_NAME)
    return "Dropped"

@app.route('/milvus/hybridsearch', methods=['GET'])
def hybrid_search():
    keyword = request.args.get('keyword')
    filters = str(request.args.get('filters')).split()
    offset = int(request.args.get('offset'))
    limit = int(request.args.get('limit'))
    return retriever(offset, limit, filters, keyword)


@app.route('/insert', methods=['POST'])
def insert_data(contents_json_filepath):
    MilvusConfig.establish_connection()
    collection = MilvusConfig.collection(DocumentData.Fields(), collection_name=COLLECTION_NAME)
    dense_index = {"index_type": "FLAT", "metric_type": "L2"}
    sparse_index = {"index_type": "SPARSE_INVERTED_INDEX", "metric_type": "IP"}

    collection.create_index(field_name="chunk_text_vec", index_params=dense_index)
    collection.create_index(field_name="sparse_text_vec", index_params=sparse_index)
    doc_details = parse_doc_details(contents_json_filepath)
    collection.load()

    MilvusConfig.load_progress(COLLECTION_NAME)
    paragraphs_list = dk8668_algo_textsplitter_list(parse_content(contents_json_filepath))
    entities = parse_doc_entities(contents_json_filepath)
    data = []
    for para in paragraphs_list:
        dense_embeddings = vec_embeddings(para)
        sparse_embeddings = sparse_encode_docs([para])
        data.append({
            'doc_id': doc_details['doc_id'],
            'chunk_text_vec': dense_embeddings,
            'sparse_text_vec': sparse_embeddings,
            'chunk_metadata': json.loads(json.dumps(entities)),
            'chunk_text': para,
            'doc_download_link': doc_details['doc_download_link'],
            'responses': 0})
    collection.insert(data)
    collection.flush()
    print(f"Data inserted successfully!")
    return "COMPLETED"


def retriever(offset, limit, filters, keyword):
    MilvusConfig.establish_connection()
    collection = MilvusConfig.collection(DocumentData.Fields(), collection_name=COLLECTION_NAME)
    search_params = {"metric_type": "L2", "offset": offset}
    search_params_sparse = {"metric_type": "IP", "offset": offset}
    dense_embeddings = vec_embeddings(keyword)
    print(dense_embeddings)
    sparse_embeddings = sparse_encode_queries([keyword])
    print(sparse_embeddings)
    # filter_json = f'chunk_metadata["fa_number"] < 3'
    if len(filters) == 0:
        filter_json = ""
    elif len(filters) == 3:
        filter_json = f'chunk_metadata["{filters[0]}"] {filters[1]} {filters[2]}'
    else:
        filter_json = f'chunk_metadata["{filters[0]}"] {filters[1]} {filters[2]} && chunk_metadata["{filters[3]}"] {filters[4]} {filters[5]}'
    print(filter_json)
    vec_search = AnnSearchRequest(
        data=[dense_embeddings],
        anns_field="chunk_text_vec",
        param=search_params,
        expr=filter_json,
        limit=limit
    )
    # print(filter_json)
    sparse_search = AnnSearchRequest(
        data=sparse_embeddings,
        anns_field="sparse_text_vec",
        param=search_params_sparse,
        expr=filter_json,
        limit=limit
    )
    print(sparse_search)

    res = collection.hybrid_search([sparse_search, vec_search], rerank=RRFRanker(),
                                   limit=limit,
                                   output_fields=["doc_id", "chunk_text", "paragraph_text", "doc_download_link",
                                                  "chunk_metadata"])

    resp_data = []
    for hit in res[0]:
        print(f'chunk_text: {hit.fields["chunk_text"]} distance {hit.distance}')
        resp_data.append(
            {"chunk_text": hit.fields["chunk_text"], "doc_id": hit.fields["doc_id"],
             "doc_download_link": hit.fields["doc_download_link"], "distance": hit.distance,
             "entities_metadata": hit.fields["chunk_metadata"]})
    return resp_data


dict_json = []


def split_keywords(keyword):
    keyword_split = keyword.split(" ")
    return keyword_split


def remove_unwanted_words(sentence: str, unwanted_texts):
    filtered_words = [word for word in word_tokenize(sentence.lower()) if word not in unwanted_texts]
    sentence = ' '.join(filtered_words)
    print(sentence)
    return sentence


def stop_words_remover(corpus):
    stop_words = set(stopwords.words('english'))

    word_tokens = word_tokenize(corpus)

    filtered_token_arr = [w for w in word_tokens if not w.lower() in stop_words]
    filtered_token_arr_lower = [text.lower() for text in filtered_token_arr]
    print("Tokens:::" + str(word_tokens))
    print("Filtered words Lower:::" + str(filtered_token_arr_lower))
    return filtered_token_arr_lower


if __name__ == '__main__':
    drop_collection()
    insert_data('DataRepository/high-performance-rag/SL-11001.json')
    insert_data('DataRepository/high-performance-rag/SL-11002.json')
    insert_data('DataRepository/high-performance-rag/SL-11003.json')
    insert_data('DataRepository/high-performance-rag/SL-11004.json')
    insert_data('DataRepository/high-performance-rag/SL-11005.json')
    insert_data('DataRepository/high-performance-rag/SL-11006.json')
    insert_data('DataRepository/high-performance-rag/SL-11007.json')

    serve(app, host='0.0.0.0', port=4000)
