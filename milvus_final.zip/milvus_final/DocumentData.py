from pymilvus import FieldSchema, DataType


class DocumentData:

    def __init__(self):
        self.fields = self

    @staticmethod
    def Fields():
        fields = [
            FieldSchema(name="chunk_id", dtype=DataType.INT64, is_primary=True, auto_id=True),
            FieldSchema(name="doc_id", dtype=DataType.VARCHAR, max_length=100),
            FieldSchema(name="chunk_text_vec", dtype=DataType.FLOAT_VECTOR, dim=1024),
            FieldSchema(name="sparse_text_vec", dtype=DataType.SPARSE_FLOAT_VECTOR),
            FieldSchema(name="chunk_text", dtype=DataType.VARCHAR, max_length=2500),
            FieldSchema(name="doc_download_link", dtype=DataType.VARCHAR, max_length=512),
            FieldSchema(name="chunk_metadata", dtype=DataType.JSON),
            FieldSchema(name="responses", dtype=DataType.INT64)
        ]
        return fields
